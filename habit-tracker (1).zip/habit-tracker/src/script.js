const monthSel = document.getElementById("month");
const tableDiv = document.getElementById("habitTable");
const perfDiv = document.getElementById("performance");
const today = new Date().toISOString().slice(0,10);

// month dropdown
for(let i=0;i<12;i++){
  let d=new Date();
  d.setMonth(d.getMonth()-i);
  monthSel.innerHTML+=`<option>${d.toISOString().slice(0,7)}</option>`;
}

function key(){
  return "data-"+monthSel.value;
}

function getData(){
  return JSON.parse(localStorage.getItem(key())) || {habits:{}, diary:{}};
}

function saveData(d){
  localStorage.setItem(key(),JSON.stringify(d));
}

function daysInMonth(){
  let [y,m]=monthSel.value.split("-");
  return new Date(y,m,0).getDate();
}

// ADD HABIT
function addHabit(){
  let h=document.getElementById("habitInput").value.trim();
  if(!h) return;

  let d=getData();
  d.habits[h]={};
  d.habits[h][today]=false;
  saveData(d);
  habitInput.value="";
  load();
}

// TOGGLE
function toggle(h,day,val){
  let d=getData();
  d.habits[h][day]=val;
  saveData(d);
  load();
}

// LOAD TABLE
function load(){
  let d=getData();
  let days=daysInMonth();

  let html="<table><tr><th>Habit</th>";
  for(let i=1;i<=days;i++) html+=`<th>${i}</th>`;
  html+="</tr>";

  let totalDone=0,totalAll=0;

  for(let h in d.habits){
    html+=`<tr><td>${h}</td>`;
    for(let i=1;i<=days;i++){
      let date=`${monthSel.value}-${String(i).padStart(2,"0")}`;
      let checked=d.habits[h][date]||false;
      if(date in d.habits[h]){
        totalAll++;
        if(checked) totalDone++;
      }
      html+=`<td>
        <input type="checkbox"
        ${checked?"checked":""}
        onchange="toggle('${h}','${date}',this.checked)">
      </td>`;
    }
    html+="</tr>";
  }

  html+="</table>";
  tableDiv.innerHTML=html;

  let p = totalAll?Math.round(totalDone/totalAll*100):0;
  perfDiv.innerText=`Overall Performance: ${p}%`;
}

// DIARY
function saveDiary(){
  let d=getData();
  d.diary[today]=document.getElementById("diary").value;
  saveData(d);
  alert("Diary saved");
}

// TIMER
let t;
function startTimer(){
  let sec=document.getElementById("minutes").value*60;
  clearInterval(t);
  t=setInterval(()=>{
    if(sec<=0){
      clearInterval(t);
      timer.innerText="Time up!";
      return;
    }
    timer.innerText=Math.floor(sec/60)+":"+("0"+sec%60).slice(-2);
    sec--;
  },1000);
}

monthSel.onchange=load;
load();
function askAI(){
  let q = document.getElementById("aiInput").value.toLowerCase();
  let d = getData();
  let habits = d.habits;
  let total=0,done=0;

  for(let h in habits){
    for(let day in habits[h]){
      total++;
      if(habits[h][day]) done++;
    }
  }

  let perf = total ? Math.round(done/total*100) : 0;
  let ans = "";

  if(q.includes("motivation")){
    ans = perf<40
      ? "Start small. Even 1 habit today is progress."
      : "You're doing well. Stay consistent!";
  }
  else if(q.includes("performance")){
    ans = `Your current performance is ${perf}%. Focus on weak days.`;
  }
  else if(q.includes("plan")){
    ans = "Plan 3 habits max per day. Use timer blocks.";
  }
  else if(q.includes("habit")){
    ans = "Track daily, not perfectly. Consistency beats intensity.";
  }
  else if(q.includes("lazy") || q.includes("tired")){
    ans = "Do minimum version of habit. Momentum matters.";
  }
  else{
    ans = "Ask about motivation, performance, plan or habits.";
  }

  document.getElementById("aiOutput").innerText = ans;
}
let focusTimer;
let focusOverlay;

function startFocus(){
  let min = document.getElementById("focusMin").value;
  if(!min || min<=0) return alert("Enter minutes");

  let sec = min * 60;

  // fullscreen
  if(document.documentElement.requestFullscreen){
    document.documentElement.requestFullscreen();
  }

  // overlay lock
  focusOverlay = document.createElement("div");
  focusOverlay.className = "focus-lock";
  focusOverlay.innerHTML = `
    <h2>FOCUS MODE ON</h2>
    <p id="focusTime"></p>
    <p>Stay focused. Do not switch apps.</p>
  `;
  document.body.appendChild(focusOverlay);

  focusTimer = setInterval(()=>{
    if(sec<=0){
      stopFocus();
      alert("Focus Session Complete 🔥");
      return;
    }
    document.getElementById("focusTime").innerText =
      Math.floor(sec/60)+":"+("0"+sec%60).slice(-2);
    sec--;
  },1000);

  document.getElementById("focusStatus").innerText="Focus Mode Running";
}

// stop
function stopFocus(){
  clearInterval(focusTimer);
  if(document.fullscreenElement) document.exitFullscreen();
  if(focusOverlay) focusOverlay.remove();
  document.getElementById("focusStatus").innerText="Focus Mode Stopped";
}

// warning if tab change
document.addEventListener("visibilitychange",()=>{
  if(document.hidden && focusOverlay){
    alert("⚠ Focus broken! Come back.");
  }
});
